﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hexgon : MangerClass
{
    private int x;
    private int y;
    private Color color;
    private int bombTimer;
    private TextMesh text;
    public Vector2 lerpPosition;
    public bool lerp;
    public int Timer { get { return bombTimer; } set { bombTimer = value; } }
    public int XPos { get { return x; } set { x = value; } }
    public int YPos { get { return y; } set { y = value; } }
    public Color _Color {  get { return color; } set { color = value; } }

    /* Struct to hold neighboor grid coordinates */
    public struct NeighbourHexes
    {
        public Vector2 up;
        public Vector2 upLeft;
        public Vector2 upRight;
        public Vector2 down;
        public Vector2 downLeft;
        public Vector2 downRight;
    }

    // Start is called before the first frame update
    void Start()
    {
        lerp = false;
        GetComponent<SpriteRenderer>().color = color;
    }

    // Update is called once per frame
    void Update()
    {
        MoveHexgonToNewPosition();
    }

    #region this section for move hexgon And change Position
    void MoveHexgonToNewPosition()
    {
        if (lerp)
        {
            float newX = Mathf.Lerp(transform.position.x, lerpPosition.x, Time.deltaTime * Hex_Move_Speed);
            float newY = Mathf.Lerp(transform.position.y, lerpPosition.y, Time.deltaTime * Hex_Move_Speed);
            transform.position = new Vector2(newX, newY);


            if (Vector3.Distance(transform.position, lerpPosition) < HEXAGON_Spaceing)
            {
                transform.position = lerpPosition;
                lerp = false;
            }
        }
    }

    /* Set new world position for hexagon */
    public void ChangeWorldPosition(Vector2 newPosition)
    {
        lerpPosition = newPosition;
        lerp = true;
    }

    /* Set new grid position for hexagon */
    public void ChangeGridPosition(Vector2 newPosition)
    {
        XPos = (int)newPosition.x;
        YPos = (int)newPosition.y;
    }

    #endregion

    #region Rotate Hexgon
    public void Rotate(int newX, int newY, Vector2 newPos)
    {
        lerpPosition = newPos;
        XPos = newX;
        YPos = newY;
        lerp = true;
    }
    #endregion


    #region slecetGroub and find NeighbourHexes
    /* Builds a struct from grid position of neighbour hexagons and returns it */
    public NeighbourHexes GetNeighbours()
    {
        NeighbourHexes neighbours;
        bool onStepper = GridManger.instance.OnStepper(XPos);


        neighbours.down = new Vector2(XPos, YPos - 1);
        neighbours.up = new Vector2(XPos, YPos + 1);
        neighbours.upLeft = new Vector2(XPos - 1, onStepper ? YPos + 1 : YPos);
        neighbours.upRight = new Vector2(XPos + 1, onStepper ? YPos + 1 : YPos);
        neighbours.downLeft = new Vector2(XPos - 1, onStepper ? YPos : YPos - 1);
        neighbours.downRight = new Vector2(XPos + 1, onStepper ? YPos : YPos - 1);


        return neighbours;
    }


    #endregion

    #region Bomb
    public void Tick(Hexgon hexBomb) { 
        --Timer; text.text = Timer.ToString();
        StartCoroutine(ChangeScaleBomb(hexBomb));
    }
    public void SetBomb()
    {
        Debug.Log("Set add Bomb");
        text = new GameObject().AddComponent<TextMesh>();
        text.alignment = TextAlignment.Center;
        text.anchor = TextAnchor.MiddleCenter;
        text.transform.localScale = transform.localScale;
        text.transform.position = new Vector3(transform.position.x, transform.position.y, -4);
        text.color = Color.white;
        text.fontStyle = FontStyle.Bold;
        text.transform.parent = transform;
        bombTimer = Bomb_Timer_Start;
        text.text = bombTimer.ToString();

    }
    // Change sacle bomb for TiCk
    IEnumerator ChangeScaleBomb(Hexgon hexBomb)
    {
        hexBomb.transform.localScale = new Vector3(.45f, .45f, 1f);
        yield return new WaitForSeconds(.5f);
        hexBomb.transform.localScale = new Vector3(.35f, .35f, 1f);
    }
    #endregion
}
