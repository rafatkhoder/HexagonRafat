﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MangerClass : MonoBehaviour
{
    // All Constant variables */

    protected const int Zero = 0;
    protected const int Double = 2;
    protected const int Half = 2;
    protected const int Default_Grid_Width = 8;
    protected const int Default_Grid_Heighe = 9;
    protected const int Default_Color_Count = 5;
    protected const int Bomb_Timer_Start = 5;
    protected const int Bomb_Score_THRESHOLD = 100;
    protected const float Hex_Distance_HORIZONTAL = 0.54f;
    protected const float Hex_Distance_VERTICAL = 0.32f;
    protected const int Grid_Vertical_OFFSET = -4;

    protected const int BOMB_SCORE_THRESHOLD = 1000;
    protected const int SCORE_CONSTANT = 5;
    protected const int SELECTION_STATUS_COUNT = 6;
    protected const int HEX_ROTATE_SLIDE_DISTANCE = 5;
    protected const int HEXAGON_ROTATE_CONSTANT = 9;

    protected const float Hex_Move_Speed = 9.0f;
    protected const float HEXAGON_Spaceing = 0.05f;
    protected const float DELAY_TO_PRODUCE_HEXAGON = 0.025f;

    protected const string TAG_HEXAGON = "Hexagon";

    protected readonly Vector3 HEX_OUTLINE_SCALE = new Vector3(0.4f, 0.4f, 1.0f);
    protected readonly Vector2 HEX_START_POSITION = new Vector3(0f, 5.0f, 0f);

   
}
