﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class InputManger : MangerClass
{
    private Vector2 touchStartPos;
    private Vector2 mousePos;
    private Hexgon selectedHexgon;
    private bool validTouch;
    private GridManger gridManger;
    
    // Start is called before the first frame update
    void Start()
    {
        gridManger = GridManger.instance;
    }

    // Update is called once per frame
    void Update()
    {
        TouchActivity();
    }

    #region Mouse Input , Touch Input ,Chechk Select And Rotate Hex
    void TouchActivity()
    {

        if (gridManger.InputAvailabile() && Input.touchCount > 0)
        {
            /* Taking collider of touched object (if exists) to a variable */
            Vector3 wp = Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position);
            Vector2 touchPos = new Vector2(wp.x, wp.y);
            Collider2D collider = Physics2D.OverlapPoint(touchPos);
            selectedHexgon = gridManger.GetSelectedHexagon();

            /* Processing input */
            TouchDetection();
            CheckSelection(collider);
            CheckRotation();
        }
        else if (gridManger.InputAvailabile() && Input.GetMouseButtonDown(0))
        {

            mousePos = Input.mousePosition;
            //Debug.Log("touch pos =  " + mousePos);
            Vector3 offset = Camera.main.ScreenToWorldPoint(new Vector3(mousePos.x, mousePos.y, 0)) - transform.position;
            Vector2 touchPos = new Vector2(offset.x, offset.y);
            Collider2D collider = Physics2D.OverlapPoint(touchPos);
            selectedHexgon = gridManger.GetSelectedHexagon();
            validTouch = true;
            CheckSelection(collider);
            //if(collider != null)
            //Debug.Log("Col name = " + collider.transform.gameObject.name);
            CheckRotation();
        }

    }

    private void TouchDetection()
    {
        /* Set start poisiton at the beginning of touch[0] */
        if (Input.GetTouch(0).phase == TouchPhase.Began)
        {
            validTouch = true;
            touchStartPos = Input.GetTouch(0).position;
        }
    }

    /* Checks if selection condition provided and calls grid manager to handle selection */
    private void CheckSelection(Collider2D collider)
    {
        /* If there is a collider and its tag match with any Hexagon continue operate */
        if (collider != null && collider.transform.tag == TAG_HEXAGON)
        {
            /* Select hexagon if touch ended */
            if (Input.touchCount > 0)
            {
                if (Input.GetTouch(0).phase == TouchPhase.Ended && validTouch)
                {
                    validTouch = false;
                    gridManger.Select(collider);
                }
            } 
            else  if (Input.GetMouseButtonDown(0) && validTouch)
            {
                //Debug.Log("iam here");
                validTouch = false;
                gridManger.Select(collider);
            }
        }
    }

    /* Checks if rotation condition provided and calls grid manager to handle rotation */
    private void CheckRotation()
    {
        if(Input.touchCount > 0)
        {
            if (Input.GetTouch(0).phase == TouchPhase.Moved && validTouch)
            {
                Vector2 touchCurrentPosition = Input.GetTouch(0).position;
                float distanceX = touchCurrentPosition.x - touchStartPos.x;
                float distanceY = touchCurrentPosition.y - touchStartPos.y;


                /* Check if rotation triggered by comparing distance between first touch position and current touch position */
                ChechkTouchDisRot(touchCurrentPosition, distanceX, distanceY);
            }
        }
        
        else if (Input.GetMouseButton(0) && validTouch)
        {
            Vector2 touchCurrentPosition = Input.mousePosition;
            float distanceX = touchCurrentPosition.x - touchStartPos.x;
            float distanceY = touchCurrentPosition.y - touchStartPos.y;
            /* Check if rotation triggered by comparing distance between first touch position and current touch position */
            ChechkTouchDisRot(touchCurrentPosition, distanceX, distanceY);
            
        }

    }
    
    void ChechkTouchDisRot(Vector2 touchPos , float disX ,float disY)
    {
        if ((Mathf.Abs(disX) > HEX_ROTATE_SLIDE_DISTANCE || Mathf.Abs(disY) > HEX_ROTATE_SLIDE_DISTANCE) && selectedHexgon != null)
        {
            Vector3 screenPosition = Camera.main.WorldToScreenPoint(selectedHexgon.transform.position);

            /* Simplifying long boolean expression thanks to ternary condition
                * triggerOnX specifies if rotate action triggered from a horizontal or vertical swipe 
                * swipeRightUp specifies if swipe direction was right or up
                * touchThanHex specifies if touch position value is bigger than hexagon position on triggered axis
                * If X axis triggered rotation with same direction swipe, then rotate clockwise else rotate counter clockwise
                * If Y axis triggered rotation with opposite direction swipe, then rotate clockwise else rotate counter clocwise
                */
            bool triggerOnX = Mathf.Abs(disX) > Mathf.Abs(disY);
            bool swipeRightUp = triggerOnX ? disX > 0 : disY > 0;
            bool touchThanHex = triggerOnX ? touchPos.y > screenPosition.y : touchPos.x > screenPosition.x;
            bool clockWise = triggerOnX ? swipeRightUp == touchThanHex : swipeRightUp != touchThanHex;


            gridManger.Rotate(clockWise);
            validTouch = false;
        }
    }
    #endregion

}