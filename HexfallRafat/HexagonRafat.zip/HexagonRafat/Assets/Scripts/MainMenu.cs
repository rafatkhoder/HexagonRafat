﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MainMenu : Singleton<MainMenu>
{
    [SerializeField] GameObject panelGame;
    [SerializeField] GameObject panelOpition;
    [SerializeField] GameObject gameOverScreen;
    [SerializeField] Text score;
    [SerializeField] Text widthValueText;
    [SerializeField] Text heightValueText;
    [SerializeField] Text colorCountText;
    [SerializeField] Slider widthSlider;
    [SerializeField] Slider heightSlider;
    [SerializeField] Slider colorCountSlider;
    [SerializeField] Button startBtn;
    [SerializeField] Button cancleBtn;

    private int blownHexagons;
    private int bombCount;
    public int MyScoreHex { get { return blownHexagons; } set { blownHexagons = value; } }
    private GridManger gridManger;

    private void Awake()
    {
        base.RegisterSingleton();

        gridManger = GridManger.instance;
    }
    private void Start()
    {
        Default();
        startBtn.onClick.AddListener(StartButton);
        cancleBtn.onClick.AddListener(CancleButton);
    }

    #region Ui Game
    void Default()
    {
        widthSlider.value = Default_Grid_Width;
        heightSlider.value = Default_Grid_Heighe;
        colorCountSlider.value = Default_Color_Count;
        panelGame.SetActive(false);
        panelOpition.SetActive(true);
        score.text = blownHexagons.ToString();
    }
    // if click start btn work this fun 
    void StartButton()
    {
        panelGame.SetActive(true);
        panelOpition.SetActive(false);
        gridManger.GridWidth = (int)widthSlider.value;
        gridManger.GridHeight = (int)heightSlider.value;
        gridManger.HexColorsCount = (int)colorCountSlider.value;
        gridManger.InitializeGrid();
        gridManger.SetColorList();
    }
    // is Back Btn for Restart A game
    void CancleButton()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void GameEnd()
    {
        panelOpition.SetActive(false);
        gameOverScreen.SetActive(true);
    }
    // the Function work in Ui for change text Val
    public void WidthSliderChange()
    {
        widthValueText.text = widthSlider.value.ToString();
    }
    // the Function work in Ui for change text Val
    public void HeightSliderChange()
    {
        heightValueText.text = heightSlider.value.ToString();
    }
    // the Function work in Ui for change text Val
    public void ColorCountSliderChange()
    {
        colorCountText.text = colorCountSlider.value.ToString();
    }
    public void Score(int x)
    {
        blownHexagons += x;
        score.text = (SCORE_CONSTANT * blownHexagons).ToString();
        if (int.Parse(score.text) > BOMB_SCORE_THRESHOLD * bombCount + BOMB_SCORE_THRESHOLD)
        {
            Debug.Log("Set Bomb");
            ++bombCount;
            gridManger.SetBombProduction();
        }
    }
    #endregion
}
