﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Singleton<T> : MangerClass where T : MangerClass
{
    public static T instance;
    private void Awake()
    {
        RegisterSingleton();
    }
    protected void RegisterSingleton()
    {
        if (instance == null)
        {
            instance = this as T;
        }
        else
        {
            Destroy(gameObject);
        }
    }
}
