﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GridManger : Singleton<GridManger>
{

    public GameObject hexPrefab;
    public Sprite outlineSprite;
    public Transform hexParent;
    public Transform outParent;

    private List<Color> hexColors = new List<Color>();
    private List<List<Hexgon>> gameGrid = new List<List<Hexgon>>();
    // vaiblas for chechk
    private bool hexgonProductionStatus;
    private bool gameEnd;
    private bool hexgonRotationStatus;
    private bool hexgonExplosionStatus;
    private bool bombProduction;
    // vaiblas for select
    private Vector2 selectedPosition;
    private Hexgon selectedHexagon;
    private List<Hexgon> selectedGroup = new List<Hexgon>();
    private List<Hexgon> bombs = new List<Hexgon>();
    private int selectionStatus;

    private int gridWidth;
    private int gridHeight;
    private int hexColorCount;

    public int GridWidth { private get { return gridWidth; }  set { gridWidth = value; } }
    public int GridHeight { private get { return gridHeight; } set { gridHeight = value; } }
    public int HexColorsCount { private get { return hexColorCount; } set { hexColorCount = value; } }

    private MainMenu mainMenu;

    void Awake()
    {
        base.RegisterSingleton();
    }
    private void Start()
    {
        mainMenu = MainMenu.instance;
    }

    #region Creat Grid Hexgon And set Colors 
    public void InitializeGrid()
    {
        List<int> gridCells = new List<int>();
        

        /* Initialize gameGrid and fill missingCells */
        for (int i = 0; i < GridWidth; ++i)
        {
            for (int j = 0; j < GridHeight; ++j)
                gridCells.Add(i);

            gameGrid.Add(new List<Hexgon>());
        }

        /* Fill grid with hexagons */
        StartCoroutine(CreatHexgon(gridCells));
        
    }
    public void SetColorList()
    {
        hexColors.Add(Color.green);
        hexColors.Add(Color.red);
        hexColors.Add(Color.blue);
        hexColors.Add(Color.yellow);
        hexColors.Add(Color.grey);

        if (hexColorCount == 6)
        {
            hexColors.Add(Color.cyan);
        }
        if (hexColorCount == 7)
        {
            hexColors.Add(Color.cyan);
            hexColors.Add(Color.magenta);
        }

    }
    public bool OnStepper(int x)
    {
        int midIndex = GridWidth / Half;
        return (midIndex % 2 == x % 2);
    }
    private float GetGridStartCoordinateX()
    {
        float newX;
        if (GridWidth == 6 || GridWidth == 8)
            newX = Hex_Distance_HORIZONTAL / Half;
        else
            newX = 0;

        return GridWidth / Half * -Hex_Distance_HORIZONTAL + newX;
    }
    private IEnumerator CreatHexgon(List<int> columns)
    {
        Vector3 startPosition;
        float positionX, positionY;
        float startX = GetGridStartCoordinateX();
        bool stepperStatus;
        List<Hexgon> explosiveHexagons = null;
        /* Indication for the beginning of hexagon production */
        hexgonProductionStatus = true;
        /* Produce new hexagon, set variables  */
        SetColorList();
        foreach (int i in columns)
        {
            /* Instantiate new hexagon and give a little delay */
            stepperStatus = OnStepper(i);
            positionX = startX + (Hex_Distance_HORIZONTAL * i);
            positionY = (Hex_Distance_VERTICAL * gameGrid[i].Count * 2) + Grid_Vertical_OFFSET + (stepperStatus ? Hex_Distance_VERTICAL : Zero);
            
            startPosition = new Vector3(positionX, positionY, Zero);

            GameObject newObj = Instantiate(hexPrefab, HEX_START_POSITION, Quaternion.identity, hexParent.transform);
            Hexgon newHex = newObj.GetComponent<Hexgon>();
            newHex._Color = hexColors[Random.Range(0,hexColors.Count)];
            yield return new WaitForSeconds(DELAY_TO_PRODUCE_HEXAGON);
            /* Set bomb if production signal has arrived */
			if (bombProduction) {
				newHex.SetBomb();
				bombs.Add(newHex);
				bombProduction = false;
			}

            newHex.ChangeGridPosition(new Vector2(i, gameGrid[i].Count));
            newHex.ChangeWorldPosition(startPosition);
            gameGrid[i].Add(newHex);
        }

        /* Indication for the end of hexagon production */
        hexgonProductionStatus = false;

        // the section for check and dstroy hex in start Game
        explosiveHexagons = CheckExplosion(gameGrid);
        if (explosiveHexagons.Count > 0)
        {
            hexgonProductionStatus = true;
            if(mainMenu.MyScoreHex >Zero)
                StartCoroutine(CreatHexgon(ExplodeHexagons(explosiveHexagons,1,false)));
            else
                StartCoroutine(CreatHexgon(ExplodeHexagons(explosiveHexagons, 0, false)));
        }
    }

    /* Helper function to validate a position if it is in game grid */
    private bool IsValid(Vector2 pos)
    {
        return pos.x >= 0 && pos.x < GridWidth && pos.y >= 0 && pos.y < GridHeight;
    }
    #endregion

    #region this Function For Select And Rotate Hexgon

    public Hexgon GetSelectedHexagon() { return selectedHexagon; }
    public bool InputAvailabile() { return !hexgonProductionStatus && !gameEnd && !hexgonRotationStatus && !hexgonExplosionStatus; }

    public void Select(Collider2D collider)
    {
        /* If selection is different than current hex, reset status and variable */
        if (selectedHexagon == null || !selectedHexagon.GetComponent<Collider2D>().Equals(collider))
        {
            selectedHexagon = collider.gameObject.GetComponent<Hexgon>();
            selectedPosition.x = selectedHexagon.XPos;
            selectedPosition.y = selectedHexagon.YPos;
            selectionStatus = 0;
        }

        /* Else increase selection status without exceeding total number */
        else
        {
            selectionStatus = (++selectionStatus) % SELECTION_STATUS_COUNT;
        }

        DestructOutline();
        ConstructOutline();
    }
    public void Rotate(bool clockWise)
    {
        /* Specifying that rotation started and destroying outliner*/
        DestructOutline();
        StartCoroutine(RotationCheckCoroutine(clockWise));
    }
    /* Function to check if all hexagons finished rotating */
    private IEnumerator RotationCheckCoroutine(bool clockWise)
    {
        List<Hexgon> explosiveHexagons = null;
        bool flag = true;

        explosiveHexagons = CheckExplosion(gameGrid);
        /* Rotate selected group until an explosive hexagon found or maximum rotation reached */
        hexgonRotationStatus = true;
        for (int i = 0; i < selectedGroup.Count; ++i)
        {
            /* Swap hexagons and wait until they are completed rotation */
            SwapHexagons(clockWise);
            yield return new WaitForSeconds(0.3f);

            /* Check if there is any explosion available, break loop if it is */
            explosiveHexagons = CheckExplosion(gameGrid);
            if (explosiveHexagons.Count > 0)
            {
                break;
            }
        }


        /* Indicate that rotation has ended and explosion starts */
        hexgonExplosionStatus = true;
        hexgonRotationStatus = false;


        /* Explode the hexagons until no explosive hexagons are available */
        while (explosiveHexagons.Count > 0)
        {
            if (flag)
            {
                hexgonProductionStatus = true;
                StartCoroutine(CreatHexgon(ExplodeHexagons(explosiveHexagons,1,true)));
                flag = false;
            }

            else if (!hexgonProductionStatus)
            {
                explosiveHexagons = CheckExplosion(gameGrid);
                flag = true;
            }

            yield return new WaitForSeconds(0.3f);
        }

        hexgonExplosionStatus = false;
        FindHexagonGroup();
        ConstructOutline();
    }
    // change Rotate pos in selected hexgon
    private void SwapHexagons(bool clockWise)
    {
        int x1, x2, x3, y1, y2, y3;
        Vector2 pos1, pos2, pos3;
        Hexgon first, second, third;

        

        if (selectedGroup.Count >0)
        {
            /* Taking each position to local variables to prevent data loss during rotation */
            first = selectedGroup[0];
            second = selectedGroup[1];
            third = selectedGroup[2];

            x1 = first.XPos; y1 = first.YPos;
            x2 = second.XPos; y2 = second.YPos;
            x3 = third.XPos; y3 = third.YPos;

            pos1 = first.transform.position;
            pos2 = second.transform.position;
            pos3 = third.transform.position;

            /* If rotation is clokwise, rotate to the position of element on next index, else rotate to previous index */
            if (clockWise)
            {
                first.Rotate(x2, y2, pos2);
                gameGrid[x2][y2] = first;

                second.Rotate(x3, y3, pos3);
                gameGrid[x3][y3] = second;

                third.Rotate(x1, y1, pos1);
                gameGrid[x1][y1] = third;
            }
            else
            {
                first.Rotate(x3, y3, pos3);
                gameGrid[x3][y3] = first;

                second.Rotate(x1, y1, pos1);
                gameGrid[x1][y1] = second;

                third.Rotate(x2, y2, pos2);
                gameGrid[x2][y2] = third;
            }
        }
        
    }
    #endregion

    #region OutlineMethods
    /* Function to clear the outline objects */
    private void DestructOutline()
    {
        if (outParent.transform.childCount > 0)
        {
            foreach (Transform child in outParent.transform)
                Destroy(child.gameObject);
        }
    }

    /* Function to build outline */
    private void ConstructOutline()
    {
        /* Get selected hexagon group */
        FindHexagonGroup();

        /* Creating outlines by creating black hexagons on same position with selected 
		 * hexagons and making them bigger than actual hexagons. AKA fake shader programming 
		 * Yes, I should learn shader programming... 
		 */
        foreach (Hexgon outlinedHexagon in selectedGroup)
        {
            GameObject go = outlinedHexagon.gameObject;
            GameObject outline =new GameObject("Outline");

            outline.transform.parent = outParent.transform;
            outline.transform.localScale = HEX_OUTLINE_SCALE;
            outline.AddComponent<SpriteRenderer>();
            outline.GetComponent<SpriteRenderer>().sprite = outlineSprite;
            outline.GetComponent<SpriteRenderer>().color = Color.white;
            outline.GetComponent<SpriteRenderer>().sortingOrder = -1;
            outline.transform.position = new Vector3(go.transform.position.x, go.transform.position.y, -1);
        }
    }
    #endregion

    #region Find same Group and other Group
    /* Helper function for Select() to find all 3 hexagons to be outlined */
    private void FindHexagonGroup()
    {
        //List<Hexagon> returnValue = new List<Hexagon>();
        Vector2 firstPos, secondPos;

        /* Finding 2 other required hexagon coordinates on grid */
        selectedHexagon = gameGrid[(int)selectedPosition.x][(int)selectedPosition.y];
        FindOtherHexagons(out firstPos, out secondPos);
        //if(selectedGroup.Count != Zero)
            selectedGroup.Clear();
        selectedGroup.Add(selectedHexagon);
        selectedGroup.Add(gameGrid[(int)firstPos.x][(int)firstPos.y].GetComponent<Hexgon>());
        selectedGroup.Add(gameGrid[(int)secondPos.x][(int)secondPos.y].GetComponent<Hexgon>());
    }
    /* Helper function for FindHexagonGroup() to locate neighbours of selected hexagon */
    private void FindOtherHexagons(out Vector2 first, out Vector2 second)
    {
        Hexgon.NeighbourHexes neighbours = selectedHexagon.GetNeighbours();
        bool breakLoop = false;


        /* Picking correct neighbour according to selection position */
        do
        {
            switch (selectionStatus)
            {
                case 0: first = neighbours.up; second = neighbours.upRight; break;
                case 1: first = neighbours.upRight; second = neighbours.downRight; break;
                case 2: first = neighbours.downRight; second = neighbours.down; break;
                case 3: first = neighbours.down; second = neighbours.downLeft; break;
                case 4: first = neighbours.downLeft; second = neighbours.upLeft; break;
                case 5: first = neighbours.upLeft; second = neighbours.up; break;
                default: first = Vector2.zero; second = Vector2.zero; break;
            }

            /* Loop until two neighbours with valid positions are found */
            if (first.x < 0 || first.x >= gridWidth || first.y < 0 || first.y >= gridHeight || 
                second.x < 0 || second.x >= gridWidth || second.y < 0 || second.y >= gridHeight)
            {
                selectionStatus = (++selectionStatus) % SELECTION_STATUS_COUNT;
            }
            else
            {
                breakLoop = true;
            }
        } while (!breakLoop);
    }
    #endregion

    #region ExplosionHelpers
    /* Returns a list that contains hexagons which are ready to explode, returns an empty list if there is none */
    private List<Hexgon> CheckExplosion(List<List<Hexgon>> listToCheck)
    {
        List<Hexgon> neighbourList = new List<Hexgon>();
        List<Hexgon> explosiveList = new List<Hexgon>();
        Hexgon currentHexagon;
        Hexgon.NeighbourHexes currentNeighbours;
        Color currentColor;


        for (int i = 0; i < listToCheck.Count; ++i)
        {
            for (int j = 0; j < listToCheck[i].Count; ++j)
            {
                /* Take current hexagon informations */
                currentHexagon = listToCheck[i][j];
                currentColor = currentHexagon._Color;
                currentNeighbours = currentHexagon.GetNeighbours();

                /* Fill neighbour list with up-upright-downright neighbours with valid positions */
                if (IsValid(currentNeighbours.up)) neighbourList.Add(gameGrid[(int)currentNeighbours.up.x][(int)currentNeighbours.up.y]);
                else neighbourList.Add(null);

                if (IsValid(currentNeighbours.upRight)) neighbourList.Add(gameGrid[(int)currentNeighbours.upRight.x][(int)currentNeighbours.upRight.y]);
                else neighbourList.Add(null);

                if (IsValid(currentNeighbours.downRight)) neighbourList.Add(gameGrid[(int)currentNeighbours.downRight.x][(int)currentNeighbours.downRight.y]);
                else neighbourList.Add(null);


                /* If current 3 hexagons are all same color then add them to explosion list */
                for (int k = 0; k < neighbourList.Count - 1; ++k)
                {
                    if (neighbourList[k] != null && neighbourList[k + 1] != null)
                    {
                        if (neighbourList[k]._Color == currentColor && neighbourList[k + 1]._Color == currentColor)
                        {
                            if (!explosiveList.Contains(neighbourList[k]))
                                explosiveList.Add(neighbourList[k]);
                            if (!explosiveList.Contains(neighbourList[k + 1]))
                                explosiveList.Add(neighbourList[k + 1]);
                            if (!explosiveList.Contains(currentHexagon))
                                explosiveList.Add(currentHexagon);
                        }
                    }
                }

                neighbourList.Clear();
            }
        }


        return explosiveList;
    }

    /* Function to clear explosive hexagons and tidy up the grid */
    private List<int> ExplodeHexagons(List<Hexgon> list , int addScore , bool bombActive)
    {
        List<int> missingColumns = new List<int>();
        float positionX, positionY;


        /* Check for bombs */
        if (bombActive)
        {
            foreach (Hexgon hex in bombs)
            {
                if (!list.Contains(hex))
                {
                    hex.Tick(hex);
                    if (hex.Timer == Zero)
                    {
                        gameEnd = true;
                        mainMenu.GameEnd();
                        StopAllCoroutines();
                        return missingColumns;
                    }
                }
            }
        }
        

        /* Remove hexagons from game grid */
        foreach (Hexgon hex in list)
        {
            if (bombs.Contains(hex))
            {
                bombs.Remove(hex);
            }
            mainMenu.Score(addScore);
            gameGrid[hex.XPos].Remove(hex);
            missingColumns.Add(hex.XPos);
            Destroy(hex.gameObject);
        }
        // وقت ينقص مربعات
        /* Re-assign left hexagon positions */
        foreach (int i in missingColumns)
        {
            for (int j = 0; j < gameGrid[i].Count; ++j)
            {
                positionX = GetGridStartCoordinateX() + (Hex_Distance_HORIZONTAL * i);
                positionY = (Hex_Distance_VERTICAL * j * 2) + Grid_Vertical_OFFSET + (OnStepper(i) ? Hex_Distance_VERTICAL : Zero);
                gameGrid[i][j].YPos = j;
                gameGrid[i][j].XPos = i;
                gameGrid[i][j].ChangeWorldPosition(new Vector3(positionX, positionY, Zero));
            }
        }

        /* Indicate the end of process and return the missing column list */
        hexgonExplosionStatus = false;
        return missingColumns;
    }

    public void SetBombProduction() { bombProduction = true; }
    #endregion

}
